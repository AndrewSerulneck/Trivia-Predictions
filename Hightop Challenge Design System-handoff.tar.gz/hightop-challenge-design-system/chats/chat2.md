# Challenges page design

_Started 2026-05-25 19:07 UTC_

---

## User

Regenerate "Venue switcher (3-tab)": Let's go with the placement on the left. Also, I think your UI misunderstands what challenges are. Challenges are not "challenges" from other users (although we are planning to add this feature to the challenges page in the future). For now, challenges are achievements users can work toward achieving by playing certain games at certain times. For instance, our "Pick 'Em" game is a game where users must try to guess which teams will win competitions. A possible challenge for users is to be the first one at their venue to win (for example) 750 'Pick 'Em points (which means they were the first to guess about 50-75 correct winners, depending on the bonuses they qualified for along the way). 

Each challenge has its own unique rules. Admins can create challenges on the admin dashboard. The rules always involve playing one of our games for a certain number of points. They usually also entail playing those challenges at certain times on certain days (a tool we are using to attempt to attract business for our partner venues at times they are usually slow by incentivizing their patrons to come to their bars because they want to play our game). Each challenge is listed on the Challenges page with a badge pertaining to that challenge (Fantasy sports challenges have Fantasy sports themed badges, Pick 'Em challenges have Pick 'Em themed challenges, Bingo challenges have "luck" or "chance" themed badges). Next to each challenge badge is a progress gauge that shows the user's progress towards winning that particular challenge. When a user wins a certain challenge, the other users at that venue see the winning user's name on the challenge card and are notified that the user won. When the user is the one who won the challenge, the challenge card becomes clickable. When they click a completed/won challenge card, they are given a coupon to the venue for whatever prize was offered for that particular challenge.

## Assistant

## User

I don’t see Speed Trivia, Pick ‘Em, or Fantasy under “Components.” Have those also been redesigned, or were they left out? 

Also, I think your UI misunderstands what challenges are. Challenges are not "challenges" from other users (although we are planning to add this feature to the challenges page in the future). For now, challenges are achievements users can work toward achieving by playing certain games at certain times. For instance, our "Pick 'Em" game is a game where users must try to guess which teams will win competitions. A possible challenge for users is to be the first one at their venue to win (for example) 750 'Pick 'Em points (which means they were the first to guess about 50-75 correct winners, depending on the bonuses they qualified for along the way). 

Each challenge has its own unique rules. Admins can create challenges on the admin dashboard. The rules always involve playing one of our games for a certain number of points. They usually also entail playing those challenges at certain times on certain days (a tool we are using to attempt to attract business for our partner venues at times they are usually slow by incentivizing their patrons to come to their bars because they want to play our game). Each challenge is listed on the Challenges page with a badge pertaining to that challenge (Fantasy sports challenges have Fantasy sports themed badges, Pick 'Em challenges have Pick 'Em themed challenges, Bingo challenges have "luck" or "chance" themed badges). Next to each challenge badge is a progress gauge that shows the user's progress towards winning that particular challenge. When a user wins a certain challenge, the other users at that venue see the winning user's name on the challenge card and are notified that the user won. When the user is the one who won the challenge, the challenge card becomes clickable. When they click a completed/won challenge card, they are given a coupon to the venue for whatever prize was offered for that particular challenge.


Regenerate "Venue switcher (3-tab)": Let's go with the placement on the left. 

Display type is odd. The inside of the lettering is dark. It looks "off."

## Assistant

_[tool: read_file]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: write_file]_

_[tool: done]_

Regenerated. Top placement only, and the body of the phone mock is now the **Challenges** view so the concept reads clearly: each card has a game-themed badge (Pick 'Em, Bingo, Fantasy), a rule line ("First to 750 Pick 'Em points", with the day/time window), a progress gauge, the live progress vs. target, and the prize. The third card shows the won/completed state — emerald border, "Tap to claim" — which is the only state where the card becomes interactive. The anatomy panel on the right spells the model out explicitly: achievements you work toward by playing a specific game in a specific time window, with the venue-wide "first to win it" race.

On your other two notes:

**Speed Trivia / Pick 'Em / Fantasy under Components** — they weren't redesigned as standalone component cards. The five gameplay identities are documented as a *system* in `colors-game-identities.html` (the gradients, edges, type, motifs for all five). Per-game gameplay surfaces (the live boards) only have **Live Trivia** (`component-live-round-break.html`, `component-live-postgame.html`) and **Bingo** (`component-bingo-board.html`) called out, because those were the screens with non-trivial recurring patterns. Speed Trivia, Pick 'Em, and Fantasy reuse the shared rules-card / countdown / feedback / buttons primitives — there wasn't a distinct component to spec. Want me to add dedicated game-surface cards for those three so the set is symmetric?

**Display type looking "off" (dark inside)** — that's the gradient text in `type-display.html`. The Trivia gradient (`#0ea5e9 → #2563eb → #7c3aed`) is mid-tone blue/violet, and once you clip it inside the letterforms the dark embossed text-shadow underneath bleeds through the gradient and the strokes read muddy. Two options: drop the `background-clip:text` and render the title in solid white with the emboss (broadcast scoreboard feel), or keep the gradient but lighten the stops so it stays bright inside the strokes. I'll wait for your call before touching it.

## User

Regenerate "Display type": I don't care how you do it but make the Display Type bright yellow or white.

## Assistant

_[tool: str_replace_edit]_

_[tool: done]_

Done — display type is now solid white with the scoreboard emboss shadow (no more gradient clipping the strokes). Reads clean and bright on the dark canvas.

## User

Regenerate "Logo": A - Slab Tubes.

## Assistant

_[tool: read_file]_

_[tool: write_file]_

_[tool: done]_

Locked Slab Tubes as the direction and built out the system around it:

- **Primary lockup** — Hightop (cyan) · yellow dash · Challenge (pink), big, on the bar backdrop
- **Stacked** version for square / vertical contexts
- **Compact** wordmark for app headers / nav
- **Icon "H"** at 60 / 34 / 22px for tab / favicon / app-tile use
- **Monochrome** fallback (single-color white, no glow) for print, embroidery, anywhere the neon FX won't render
- **Tube spec** card: swatches, type spec, glow formula, min sizes
- Legacy top-hat mark retired to a small reference strip at the bottom

## User

Save as standalone HTML: the current design

## Assistant

_[tool: copy_files]_

_[tool: str_replace_edit]_

_[tool: super_inline_html]_

_[tool: show_html]_

_[tool: get_webview_logs]_

_[tool: present_fs_item_for_download]_

Standalone file ready — single self-contained HTML, fonts and the legacy SVG inlined.

